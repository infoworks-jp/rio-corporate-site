株式会社 吏央 コーポレートアイデンティティ
ロゴの墨色: C60 M40 Y40 K100 リッチブラック / 総インキ量240%
CMYK形式のIllustratorファイル。Editableは文字編集用、Outlinedはアウトライン済み。
使用フォント: 新ゴPro Regular/Bold、Helvetica、リュウミンPro Regular。
